# Python Lab Assignment 6 — Data Preprocessing

## Files
- `assignment6.py` — Python program for preprocessing.
- `student_data.csv` — sample input dataset with missing and duplicate values.
- `cleaned_data.csv` — generated automatically when the program runs.

## Requirements
Install Pandas:
```bash
python -m pip install pandas
```

## Run
Keep `assignment6.py` and `student_data.csv` in the same folder, then run:
```bash
python assignment6.py
```
