import pandas as pd

# Load the CSV dataset
df = pd.read_csv("student_data.csv")

print("Original Data:")
print(df)

# Explore the dataset
print("\nFirst five rows:")
print(df.head())

print("\nDataset information:")
df.info()

print("\nStatistical summary:")
print(df.describe())

# Check missing values
print("\nMissing values:")
print(df.isnull().sum())

# Handle missing values
df["Marks"] = df["Marks"].fillna(df["Marks"].mean())
df["City"] = df["City"].fillna("Unknown")

print("\nAfter handling missing values:")
print(df)

# Identify duplicate rows
print("\nDuplicate rows:")
print(df.duplicated())

# Remove duplicate rows
df = df.drop_duplicates()

print("\nAfter removing duplicates:")
print(df)

# Example of removing an irrelevant column (uncomment if needed)
# df = df.drop(columns=["City"])

# Select students scoring above 80
print("\nStudents scoring above 80:")
print(df.loc[df["Marks"] > 80])

# Save the cleaned dataset
df.to_csv("cleaned_data.csv", index=False)
print("\nCleaned data saved as cleaned_data.csv")
